package com.example.sagz.cfgjpmc;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;


public class Form extends ActionBarActivity
{
    TextView tv,curr_date;
    EditText delay,week_no;
    Button submit;
    int task_value;
    String url;
    String username,schoolname;
    SQLiteDatabase db;
    int insert_flag=0;
    String mypath = Environment.getExternalStorageDirectory() + "/CFG/";
    String motherpath= Environment.getExternalStorageDirectory()+"/CFG/";
    protected boolean taken;

    protected static final String PHOTO_TAKEN	= "photo_taken";

    String db_task,db_username,db_schoolname,db_date;
    boolean haveConnectedWifi = false;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy =
                    new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#ff7701")));
        actionBar.setTitle(Html.fromHtml("<font color='#FFFFFF'>Happy Hearts Fund</font>"));


        SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(Form.this);
        username=pref.getString("username","");
        schoolname=pref.getString("schoolname","");

        tv=(TextView)findViewById(R.id.textView);
        curr_date=(TextView)findViewById(R.id.textView2);
        week_no=(EditText)findViewById(R.id.editText5);

        DateFormat dateFormat = new SimpleDateFormat("MM/dd");
        Date date = new Date();
        curr_date.setText(dateFormat.format(date));

        db=openOrCreateDatabase("Activity_DB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS schooldetails(task VARCHAR,delay VARCHAR,username VARCHAR,schoolname VARCHAR,photo VARCHAR,date VARCHAR);");

        new CheckConnection().execute();
    }

    public void onclick(View v)
    {
        switch (v.getId())
        {
            case R.id.button4:



                        db.execSQL("INSERT INTO schooldetails(task,username,schoolname,date) VALUES('" + task_value + "','" +
                                username + "','" + schoolname + "','" + week_no.getText().toString() + "');");

                        Toast.makeText(getApplicationContext(), "BACK UP OFFLINE DONE", Toast.LENGTH_LONG).show();

                        new CheckConnection().onPostExecute("s");



                break;

            case R.id.button3:

                String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss",
                        Locale.getDefault()).format(new Date());


                File file = new File(mypath,""+timestamp+".jpg");

                Uri outputFileUri = Uri.fromFile(file);

                Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE );

                intent.putExtra( MediaStore.EXTRA_OUTPUT, outputFileUri );

                startActivityForResult(intent,0);

                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        switch (resultCode)
        {
            case 0:
                Toast.makeText(Form.this, "Cancelled ! ", Toast.LENGTH_SHORT).show();
                break;

            case -1:

                onPhotoTaken();

                Toast.makeText(Form.this,"Photo Stored At "+motherpath,Toast.LENGTH_LONG);
                break;
        }


    }

    protected void onPhotoTaken()
    {


        taken = true;

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 4;

        Bitmap bitmap = BitmapFactory.decodeFile( mypath, options );

    }


    public void SendData()
    {
        url="http://ec2-52-69-49-99.ap-northeast-1.compute.amazonaws.com/app_details.php";

        ArrayList<NameValuePair> postParameters = new ArrayList<NameValuePair>();
        postParameters.add(new BasicNameValuePair("task",""+db_task));
        postParameters.add(new BasicNameValuePair("date",db_date));
        postParameters.add(new BasicNameValuePair("username",db_username));
        postParameters.add(new BasicNameValuePair("schoolname",db_schoolname));

       // Toast.makeText(this,username+schoolname,Toast.LENGTH_LONG).show();
        try
        {
            String response = CustomHttpClient.executeHttpPost(
                    url,  // in case of a remote server
                    postParameters);

            Toast.makeText(Form.this,"Submitted...",Toast.LENGTH_LONG).show();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }



    }

    public void radioclick(View v)
    {
        switch (v.getId())
        {
                case R.id.radioButton:
                task_value=1;
                break;

            case R.id.radioButton2:
                task_value=2;
                break;

            case R.id.radioButton3:
                task_value=3;
                break;

            case R.id.radioButton4:
                task_value=4;
                break;

            case R.id.radioButton5:
                task_value=5;
                break;

            case R.id.radioButton6:
                task_value=6;
                break;

            case R.id.radioButton7:
                task_value=7;
                break;

            case R.id.radioButton8:
                task_value=8;
                break;

            case R.id.radioButton9:
                task_value=9;
                break;

            case R.id.radioButton10:
                task_value=10;
                break;
        }
    }


    public class CheckConnection extends AsyncTask<String,String,String>
    {


        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params)
        {



            while (haveConnectedWifi!=true)
            {

                ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo[] netInfo = cm.getAllNetworkInfo();
                for (NetworkInfo ni : netInfo)
                {
                    if (ni.getTypeName().equalsIgnoreCase("WIFI"))
                    {
                        if (ni.isConnected())
                        {
                            haveConnectedWifi = true;
                        }
                    }

                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s)
        {
            super.onPostExecute(s);


            if(haveConnectedWifi)
            {

                Cursor c=db.rawQuery("SELECT * FROM schooldetails", null);

                StringBuffer buffer=new StringBuffer();
                while(c.moveToNext())
                {

                    db_task=c.getString(0);
                    db_username=c.getString(2);
                    db_schoolname=c.getString(3);
                    db_date=c.getString(5);
                    /*buffer.append("Task: "+c.getString(0)+"\n");
                    buffer.append("EMAIL: "+c.getString(1)+"\n");
                    buffer.append("Username: "+c.getString(2)+"\n");
                    buffer.append("Schoolname: "+c.getString(3)+"\n");
                    buffer.append("Date: "+c.getString(5)+"\n\n");
                    */


                }


                    SendData();
                    Toast.makeText(Form.this, "BACKUP DATA SYNCED ONLINE", Toast.LENGTH_LONG).show();

              /*  AlertDialog builder=new AlertDialog.Builder(Form.this).create();
                builder.setCancelable(true);
                builder.setTitle("VIEWS KB28");
                builder.setMessage(buffer.toString());
                builder.show();
                */
            }
        }
    }





    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_form, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
