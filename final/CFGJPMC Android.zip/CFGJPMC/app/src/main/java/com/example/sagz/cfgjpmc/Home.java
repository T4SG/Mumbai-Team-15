package com.example.sagz.cfgjpmc;

import android.app.ActionBar;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.Locale;


public class Home extends ActionBarActivity {

    EditText school;
    String user_name="kunal";
    String motherpath= Environment.getExternalStorageDirectory()+"/CFG/";

    protected boolean taken;

    protected static final String PHOTO_TAKEN	= "photo_taken";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#ff7701")));
        actionBar.setTitle(Html.fromHtml("<font color='#FFFFFF'>Happy Hearts Fund</font>"));

        school = (EditText) findViewById(R.id.editText4);


    }

    public void click(View v)
    {
        switch ( v.getId())
        {
            case R.id.button6:

                SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(Home.this);
                SharedPreferences.Editor editor=pref.edit();
                editor.putString("username",user_name);
                editor.putString("schoolname",school.getText().toString());
                editor.apply();

                Intent i=new Intent(Home.this,Form.class);
                startActivity(i);

            break;
        }
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
